# Nevermore Code Testing

Test Instructions:

Somewhere on your PC, move the contents of the test to a new folder, not within the repository (So you don't accidentally commit a bunch of files that you shouldn't.)

Create a folder called "plugins" in the same folder as docker-compose.yml

Download https://github.com/neo4j-contrib/neo4j-apoc-procedures/releases/download/4.2.0.2/apoc-4.2.0.2-all.jar
and place it into the plugins folder

Run: 
  ```
  docker-compose up -d
  ```
In order to view the neo4j browser you can view it at http://localhost:7474/browser/

The testdev username and password are neo4j/testdev


Next create a config.json file in the ../config/ directory containing

```json
{
  "host": "127.0.0.1",
  "dbuname": "neo4j",
  "dbpword": "testdev",
  "dbaddress": "127.0.0.1",
  "port": "4001"
}
```

  Then to run the server cd to the server directory and run:
  ```
  go build server.go
  ```
  Followed by
    ```
  ./server
     ```

The server comes equipped with an item, a mob, and a room, and a GM account with the username "TestDev" password "testtest"

To stop the server, press ctrl+c

In order to stop neo4j, cd to the directory you chose to move the neo4j files to and run:
  ```
  docker-compose down
  ```
